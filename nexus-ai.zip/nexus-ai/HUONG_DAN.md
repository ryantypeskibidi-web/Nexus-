# 🚀 HƯỚNG DẪN DEPLOY NEXUS AI LÊN VERCEL

## CẤU TRÚC THƯ MỤC
```
nexus-ai/
├── api/
│   └── chat.js        ← Backend (ẩn API key)
├── public/
│   └── index.html     ← Giao diện chatbot
└── vercel.json        ← Cấu hình Vercel
```

---

## BƯỚC 1 — Tạo tài khoản Groq (lấy API key miễn phí)

1. Vào https://console.groq.com
2. Đăng ký bằng Google
3. Vào mục **API Keys** → **Create API Key**
4. Copy key lại (dạng: `gsk_xxxxxxxxxxxx`)

---

## BƯỚC 2 — Upload code lên GitHub

1. Vào https://github.com → Đăng ký / Đăng nhập
2. Nhấn **New repository** → Đặt tên `nexus-ai` → **Create**
3. Trên điện thoại dùng app **GitHub Mobile** hoặc trình duyệt:
   - Tạo 3 file đúng theo cấu trúc thư mục ở trên
   - Copy nội dung từng file vào

---

## BƯỚC 3 — Deploy lên Vercel

1. Vào https://vercel.com → Đăng nhập bằng GitHub
2. Nhấn **Add New Project**
3. Chọn repo `nexus-ai` vừa tạo → **Import**
4. **QUAN TRỌNG** — Trước khi Deploy, vào **Environment Variables**:
   - Name: `GROQ_API_KEY`
   - Value: paste API key Groq vào đây
5. Nhấn **Deploy** → Chờ ~1 phút

✅ Xong! Vercel sẽ cho bạn link dạng: `https://nexus-ai-xxx.vercel.app`

---

## BƯỚC 4 — Test thử

Mở link Vercel → Gõ câu hỏi bất kỳ → 3 AI sẽ trả lời!

---

## 💰 KIẾM TIỀN

### Cách 1 — Donate (dễ nhất)
- Tạo tài khoản Ko-fi: https://ko-fi.com
- Thêm nút donate vào trang

### Cách 2 — Bán gói dùng
- Dùng **Gumroad** tạo sản phẩm $5-10/tháng
- Người mua nhận link riêng có API key của họ

### Cách 3 — Làm cho khách hàng
- Chỉnh logo, màu sắc theo yêu cầu
- Bán chatbot custom $50-200/app cho shop, doanh nghiệp nhỏ

---

## ❓ LỖI THƯỜNG GẶP

| Lỗi | Nguyên nhân | Cách sửa |
|-----|-------------|----------|
| "Lỗi kết nối API" | Sai API key | Kiểm tra lại GROQ_API_KEY trong Vercel |
| Trang trắng | Sai cấu trúc thư mục | Đảm bảo đúng 3 file như trên |
| 404 /api/chat | Thiếu vercel.json | Upload lại file vercel.json |
